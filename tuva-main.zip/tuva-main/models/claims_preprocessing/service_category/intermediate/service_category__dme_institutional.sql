{{ config(
     enabled = var('claims_preprocessing_enabled',var('claims_enabled',var('tuva_marts_enabled',False))) | as_bool
   )
}}

select distinct
      med.claim_id
    , med.claim_line_number
    , med.data_source
    , med.claim_line_id
, 'ancillary' as service_category_1
, 'durable medical equipment' as service_category_2
, 'durable medical equipment' as service_category_3
, '{{ this.name }}' as source_model_name
, cast('{{ var('tuva_last_run') }}' as {{ dbt.type_timestamp() }}) as tuva_last_run
from {{ ref('service_category__stg_medical_claim') }} as med
inner join {{ ref('service_category__stg_outpatient_institutional') }} as outpatient
  on med.claim_id = outpatient.claim_id
  and med.data_source = outpatient.data_source
where med.ccs_category = '243'
