select
    immunization_id
    , person_id
    , patient_id
    , encounter_id
    , source_code_type
    , source_code
    , source_description
    , normalized_code_type
    , normalized_code
    , normalized_description
    , status
    , status_reason
    , occurrence_date
    , source_dose
    , normalized_dose
    , lot_number
    , body_site
    , route
    , location_id
    , practitioner_id
    , data_source
    , file_name
    , ingest_datetime
from {{ ref('immunization_seed') }}
